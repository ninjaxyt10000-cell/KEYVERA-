import { useState } from "react";

export default function App() {
  const [search, setSearch] = useState("");

  const properties = [
    { id: 1, title: "شقة على البحر - البيطاش", price: "1,800,000 جنيه", type: "بيع" },
    { id: 2, title: "شقة سوبر لوكس - العجمي", price: "2,200,000 جنيه", type: "بيع" },
    { id: 3, title: "استوديو للإيجار - الهانوفيل", price: "7,000 / شهر", type: "إيجار" }
  ];

  const filtered = properties.filter(p =>
    p.title.includes(search)
  );

  return (
    <div className="container">
      <header className="header">
        <h1>KEYVERA</h1>
        <p>وسيطك العقاري في البيطاش والعجمي - الإسكندرية</p>

        <a
          className="whatsapp"
          href="https://wa.me/201206369219"
          target="_blank"
        >
          تواصل واتساب مباشر
        </a>
      </header>

      <input
        className="search"
        placeholder="ابحث في البيطاش أو العجمي..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <div className="grid">
        {filtered.map((p) => (
          <div key={p.id} className="card">
            <h3>{p.title}</h3>
            <p>{p.type}</p>
            <b>{p.price}</b>
          </div>
        ))}
      </div>

      <footer>© 2026 KEYVERA</footer>
    </div>
  );
}
